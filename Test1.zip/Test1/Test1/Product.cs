﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1
{
	class Product
	{
		string id;
		string name;
		decimal price;

		public string Id { get => id; set => id = value; }
		public string Name { get => name; set => name = value; }
		public decimal Price { get => price; set => price = value; }

		
	}
}
