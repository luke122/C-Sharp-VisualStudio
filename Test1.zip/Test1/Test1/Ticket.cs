﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1
{
	class Ticket : Product
	{
		decimal serviceFee;

		public decimal ServiceFee { get => serviceFee; set => serviceFee = value; }

		public decimal GetTotalCost()
		{
			return Price + ServiceFee;
		}

		public string GetDisplayText()
		{
			return Id + "-" + Name + "-" + Price + "-" + serviceFee;
		}

	}
}
