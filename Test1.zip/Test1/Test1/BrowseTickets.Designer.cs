﻿namespace Test1
{
	partial class BrowseTickets
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ticketList = new System.Windows.Forms.ListBox();
			this.btnAddTicket = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnDeveloper = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// ticketList
			// 
			this.ticketList.FormattingEnabled = true;
			this.ticketList.Location = new System.Drawing.Point(32, 40);
			this.ticketList.Name = "ticketList";
			this.ticketList.Size = new System.Drawing.Size(287, 277);
			this.ticketList.TabIndex = 0;
			// 
			// btnAddTicket
			// 
			this.btnAddTicket.Location = new System.Drawing.Point(304, 358);
			this.btnAddTicket.Name = "btnAddTicket";
			this.btnAddTicket.Size = new System.Drawing.Size(123, 39);
			this.btnAddTicket.TabIndex = 1;
			this.btnAddTicket.Text = "Add a Ticket";
			this.btnAddTicket.UseVisualStyleBackColor = true;
			this.btnAddTicket.Click += new System.EventHandler(this.btnAddTicket_Click);
			// 
			// btnClose
			// 
			this.btnClose.Location = new System.Drawing.Point(520, 363);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(82, 28);
			this.btnClose.TabIndex = 2;
			this.btnClose.Text = "Close";
			this.btnClose.UseVisualStyleBackColor = true;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnDeveloper
			// 
			this.btnDeveloper.Location = new System.Drawing.Point(663, 363);
			this.btnDeveloper.Name = "btnDeveloper";
			this.btnDeveloper.Size = new System.Drawing.Size(75, 23);
			this.btnDeveloper.TabIndex = 3;
			this.btnDeveloper.Text = "Developer";
			this.btnDeveloper.UseVisualStyleBackColor = true;
			this.btnDeveloper.Click += new System.EventHandler(this.btnDeveloper_Click);
			// 
			// BrowseTickets
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.btnDeveloper);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnAddTicket);
			this.Controls.Add(this.ticketList);
			this.Name = "BrowseTickets";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.ListBox ticketList;
		private System.Windows.Forms.Button btnAddTicket;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnDeveloper;
	}
}

