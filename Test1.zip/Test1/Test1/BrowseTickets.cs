﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test1
{
	public partial class BrowseTickets : Form
	{
		List<Product> list = new List<Product>();

		public BrowseTickets()
		{
			InitializeComponent();
		}

		private void btnAddTicket_Click(object sender, EventArgs e)
		{
			NewTicket n = new NewTicket();
			n.ShowDialog();
			Ticket newTicket = n.TicketData;
			list.Add(newTicket);
			ticketList.Items.Clear();
			foreach (Ticket itm in list)
			{
				ticketList.Items.Add(itm.GetDisplayText());
			}


		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void btnDeveloper_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Luke Yager");
		}
	}
}
