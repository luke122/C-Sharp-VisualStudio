﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test1
{
	public partial class NewTicket : Form
	{
		Ticket ticketData = null;

		internal Ticket TicketData { get => ticketData; set => ticketData = value; }

		public NewTicket()
		{
			InitializeComponent();
		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void label3_Click(object sender, EventArgs e)
		{

		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			decimal price;
			decimal fee;

			try
			{
				price = decimal.Parse(txtPrice.Text);
			}
			catch
			{
				MessageBox.Show("Please enter a number for the price.");
				txtPrice.Focus();
				return;
			}

			try
			{
				fee = decimal.Parse(txtProcessFee.Text);
			}
			catch
			{
				MessageBox.Show("Please enter a number for the process fee.");
				txtProcessFee.Focus();
				return;
			}




			TicketData = new Ticket() {
				Id = txtID.Text,
				Name = txtName.Text,
				Price = price,
				ServiceFee = fee,

			};

			MessageBox.Show("The total cost is " + ticketData.GetTotalCost().ToString("c"));

		}
	}
}
