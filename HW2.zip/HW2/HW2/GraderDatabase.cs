﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HW2
{
    class GraderDatabase
    {
        static public void saveGrader(List<Grader> GraderList)
        {
            StreamWriter textOut = new StreamWriter(
                new FileStream("GraderList.txt", FileMode.Create,
                FileAccess.Write)
                );

            foreach (Grader g in GraderList)
            {
                //write the data of each grader to the file
                textOut.WriteLine(g.GetDisplayText());
            }

			textOut.Close();
		}
    }
}
