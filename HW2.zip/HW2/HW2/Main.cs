﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW2
{
    public partial class Main : Form
    {
        List<Grader> list = new List<Grader>();

        public Main()
        {
            InitializeComponent();
        }

        private void btnNewGrader_Click(object sender, EventArgs e)
        {
            NewGrader n = new NewGrader();
            n.ShowDialog();
            Grader newGdr = n.GraderData;
            list.Add(newGdr);
            fillListBox();
			GraderDatabase.saveGrader(list);
			



		}

        private void fillListBox()
        {
            graderList.Items.Clear();

            foreach(Grader itm in list)
            {
                graderList.Items.Add(itm.GetDisplayText());
            }
        }

        private void btnNewGraduateGrader_Click(object sender, EventArgs e)
        {
            NewGraduateGrader n = new NewGraduateGrader();
            n.ShowDialog();
            GraduateGrader newGdGrader = n.GraduateGraderData;
			list.Add(newGdGrader);
			fillListBox();
			GraderDatabase.saveGrader(list);



        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}
