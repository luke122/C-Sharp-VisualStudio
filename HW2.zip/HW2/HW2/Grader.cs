﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW2
{
    public class Grader
    {
        string ID;
        string FirstName;
        string LastName;
        decimal HourlyPay;
        decimal Hours;

        public string ID1 { get => ID; set => ID = value; }
        public string FirstName1 { get => FirstName; set => FirstName = value; }
        public string LastName1 { get => LastName; set => LastName = value; }
        public decimal HourlyPay1 { get => HourlyPay; set => HourlyPay = value; }
        public decimal Hours1 { get => Hours; set => Hours = value; }

        public string GetDisplayText()
        {
            return ID + "-" + FirstName + "-" + LastName + "-" + HourlyPay.ToString("c") + "-" + Hours.ToString();
        }

        public virtual string ToFileString()
        {
            return ID + "-" + FirstName + "-" + LastName + "-" + HourlyPay.ToString("c") + "-" + Hours.ToString();
        }

        public virtual decimal GetTotalPay()
        {
            return HourlyPay * Hours;
        }
    }
}
