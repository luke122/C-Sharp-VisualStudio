﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW2
{
    public partial class NewGrader : Form
    {
        Grader graderData = null;

        public NewGrader()
        {
            InitializeComponent();
        }

        public Grader GraderData { get => graderData; set => graderData = value; }

        private void btnCreateGrader_Click(object sender, EventArgs e)
        {
            decimal hourlyPayRate;
            decimal totalHours;

            try
            {
                hourlyPayRate = decimal.Parse(txtHourlyPayRate.Text);
            }
            catch
            {
                MessageBox.Show("Please enter a number for the hourly pay rate.");
                txtHourlyPayRate.Focus();
                return;
            }

            try
            {
                totalHours = decimal.Parse(txtHours.Text);
            }
            catch
            {
                MessageBox.Show("Please enter a number for the hours worked.");
                txtHours.Focus();
                return;
            }

            graderData = new Grader()
            {
                ID1 = txtID.Text,
                FirstName1 = txtFirstName.Text,
                LastName1 = txtLastName.Text,
                HourlyPay1 = hourlyPayRate,
                Hours1 = totalHours
            };

			MessageBox.Show("The grader's total pay is: " + graderData.GetTotalPay().ToString("c"));

        }

        private void NewGrader_Load(object sender, EventArgs e)
        {

        }
    }
}
