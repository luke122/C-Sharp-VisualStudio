﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW2
{
    public class GraduateGrader : Grader
    {
        private decimal stipend;

        public decimal Stipend { get => stipend; set => stipend = value; }

        public override decimal GetTotalPay()
        {
            return base.GetTotalPay() + stipend;
        }

        public override string ToFileString()
        {
            return base.ToFileString();
        }
    }
}
