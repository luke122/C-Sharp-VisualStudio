﻿namespace HW2
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnNewGrader = new System.Windows.Forms.Button();
			this.btnNewGraduateGrader = new System.Windows.Forms.Button();
			this.graderList = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// btnNewGrader
			// 
			this.btnNewGrader.Location = new System.Drawing.Point(335, 109);
			this.btnNewGrader.Name = "btnNewGrader";
			this.btnNewGrader.Size = new System.Drawing.Size(120, 23);
			this.btnNewGrader.TabIndex = 0;
			this.btnNewGrader.Text = " Add a Grader";
			this.btnNewGrader.UseVisualStyleBackColor = true;
			this.btnNewGrader.Click += new System.EventHandler(this.btnNewGrader_Click);
			// 
			// btnNewGraduateGrader
			// 
			this.btnNewGraduateGrader.Location = new System.Drawing.Point(335, 193);
			this.btnNewGraduateGrader.Name = "btnNewGraduateGrader";
			this.btnNewGraduateGrader.Size = new System.Drawing.Size(152, 23);
			this.btnNewGraduateGrader.TabIndex = 1;
			this.btnNewGraduateGrader.Text = "Add a Graduate Grader";
			this.btnNewGraduateGrader.UseVisualStyleBackColor = true;
			this.btnNewGraduateGrader.Click += new System.EventHandler(this.btnNewGraduateGrader_Click);
			// 
			// graderList
			// 
			this.graderList.FormattingEnabled = true;
			this.graderList.Location = new System.Drawing.Point(32, 45);
			this.graderList.Name = "graderList";
			this.graderList.Size = new System.Drawing.Size(297, 329);
			this.graderList.TabIndex = 2;
			// 
			// Main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.graderList);
			this.Controls.Add(this.btnNewGraduateGrader);
			this.Controls.Add(this.btnNewGrader);
			this.Name = "Main";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Main_Load);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNewGrader;
        private System.Windows.Forms.Button btnNewGraduateGrader;
        private System.Windows.Forms.ListBox graderList;
    }
}

