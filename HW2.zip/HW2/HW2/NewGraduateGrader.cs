﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW2
{
    public partial class NewGraduateGrader : Form
    {
        GraduateGrader graduateGraderData = null;

        public NewGraduateGrader()
        {
            InitializeComponent();
        }

        public GraduateGrader GraduateGraderData { get => graduateGraderData; set => graduateGraderData = value; }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            decimal hourlyPayRate;
            decimal totalHours;
            decimal theStipend;

            try
            {
                hourlyPayRate = decimal.Parse(txtHourlyPayRate.Text);
            }
            catch
            {
                MessageBox.Show("Please enter a number for the hourly pay rate.");
                txtHourlyPayRate.Focus();
                return;
            }

            try
            {
                totalHours = decimal.Parse(txtHours.Text);
            }
            catch
            {
                MessageBox.Show("Please enter a number for the hours worked.");
                txtHours.Focus();
                return;
            }

            try
            {
                theStipend = decimal.Parse(txtStipend.Text);
            }
            catch
            {
                MessageBox.Show("Please enter a number for the stipend.");
                txtHours.Focus();
                return;
            }


            GraduateGraderData = new GraduateGrader()
            {
                ID1 = txtID.Text,
                FirstName1 = txtFirstName.Text,
                LastName1 = txtLastName.Text,
                HourlyPay1 = hourlyPayRate,
                Hours1 = totalHours,
                Stipend = theStipend
            };

			MessageBox.Show("The graduate grader's total pay is: " + graduateGraderData.GetTotalPay().ToString("c"));
        }
    }
}
