﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{
	public class Song
	{
		int id;
		string title;
		decimal price;
		int sales;

		public int Id { get => id; set => id = value; }
		public string Title { get => title; set => title = value; }
		public decimal Price { get => price; set => price = value; }
		public int Sales { get => sales; set => sales = value; }

		public decimal GetRevenue(decimal Sales, decimal Price)
		{
			return Sales * Price;
		}
	}
}
