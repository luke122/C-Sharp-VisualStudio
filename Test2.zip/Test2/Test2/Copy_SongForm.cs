﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test2
{ 
	public partial class Copy_SongForm : Form
	{
		Song sg;
		Boolean isForModification;

		public Copy_SongForm()
		{
			InitializeComponent();
		}

		public Song Sg { get => sg; set => sg = value; }
		public bool IsForModification { get => isForModification; set => isForModification = value; }

		private void Copy_SongForm_Load(object sender, EventArgs e)
		{
			if (sg != null)
			{
				txtId.Text = sg.Id.ToString();
				txtTitle.Text = sg.Title;
				txtPrice.Text = sg.Price.ToString();
				txtSales.Text = sg.ToString();
			}
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			{
				sg = new Song();
				sg.Id = int.Parse(txtId.Text);
				sg.Title = txtTitle.Text;
				sg.Price = decimal.Parse(txtPrice.Text);
				sg.Sales = int.Parse(txtSales.Text);

				//Send the client object to the Database layer (Insert)
				SongDB.AddSong(sg);
				MessageBox.Show("The addition was successful.");
				decimal revenue = sg.GetRevenue(sg.Price, sg.Sales);
				MessageBox.Show("The song's revenue is: " + revenue);
			}
		}
	}
}
