﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test2
{

	public partial class Form1 : Form
	{
		List<Song> songs;

		public Form1()
		{
			InitializeComponent();
		}

		private void gvSong_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			Copy_SongForm form = new Copy_SongForm();
			form.Sg = songs[e.RowIndex];
			form.IsForModification = true;
			form.ShowDialog();

			//Refresh the data grid view
			try
			{
				songs = SongDB.GetAllSongs();
				dgvSong.DataSource = songs;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

			
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			try
			{
				songs = SongDB.GetAllSongs();
				dgvSong.DataSource = songs;
				dgvSong.Columns[0].HeaderText = "id";
				dgvSong.Columns[1].HeaderText = "title";
				DataGridViewButtonColumn copyColumn = new DataGridViewButtonColumn();
				copyColumn.HeaderText = "";
				copyColumn.UseColumnTextForButtonValue = true;
				copyColumn.Text = "Copy";
				dgvSong.Columns.Add(copyColumn);

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}
}
