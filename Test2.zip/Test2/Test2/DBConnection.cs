﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{
	public static class DBConnection
	{
		public static string ConnectionString()
		{
			return "Data Source=sql.mccoy.txstate.edu;Initial Catalog=cis3325_students;Persist Security Info=True;User ID=bobcat3325;Password=Ci$404404";
		}
	}
}
