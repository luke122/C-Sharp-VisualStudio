﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{
	public class SongDB
	{
		public static List<Song> GetAllSongs()
		{
			List<Song> list = new List<Song>();

			//Get a connection 
			SqlConnection conn = new SqlConnection(DBConnection.ConnectionString());

			//Prepare for a SQL statement
			string sqlString = "select * from song";
			SqlCommand select = new SqlCommand(sqlString, conn);

			try
			{
				//Execute the SQL command
				conn.Open();
				SqlDataReader reader = select.ExecuteReader();

				//populate the list object
				while (reader.Read())
				{
					Song sg = new Song();
					sg.Id = (int)reader["id"]; //case sentitive
					sg.Title = (string)reader["title"];
					sg.Price = (decimal)reader["price"];
					sg.Sales = (int)reader["sales"];

					//Add the new client to the list
					list.Add(sg);

				}
			}
			catch (Exception ex)
			{
				throw ex;

			}
			finally
			{
				conn.Close();
			}

			return list;
		}

		public static void AddSong(Song songs)
		{
			//Get a connection 
			SqlConnection conn = new SqlConnection(DBConnection.ConnectionString());

			//Prepare for a SQL statement
			string sqlString = "insert into song values(@id, @title, @price, @sales)";
			SqlCommand insert = new SqlCommand(sqlString, conn);
			insert.Parameters.AddWithValue("@id", songs.Id);
			insert.Parameters.AddWithValue("@title", songs.Title);
			insert.Parameters.AddWithValue("@price", songs.Price);
			insert.Parameters.AddWithValue("@sales", songs.Sales);

			try
			{
				conn.Open();
				insert.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				conn.Close();
			}

		}
	}
}
