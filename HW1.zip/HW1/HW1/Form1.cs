﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SortedList<string, decimal> sales = null;
            sales = new SortedList<string, decimal>();
            sales.Add("Adams", 15.80m);
            sales.Add("Boylan", 12.78m);
            sales.Add("Douglas", 11.23m);
            sales.Add("Yager", 15.40m);

            string msg = "";
            foreach (KeyValuePair<string, decimal> element in sales)
            {
                msg = msg + element.Key + "\t" + element.Value.ToString("c") + "\n";
            }
            MessageBox.Show(msg);
        }
    }
}
